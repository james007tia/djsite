from django.apps import AppConfig


class DatingAppConfig(AppConfig):
    name = 'dating_app'
